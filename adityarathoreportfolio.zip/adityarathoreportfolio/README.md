# Aditya Rathore — AI, Data Science & Python Portfolio

A static portfolio website built with HTML, Tailwind CSS, Three.js, and Vanilla Tilt.

## Run locally

Open `index.html` in a browser while connected to the internet (the page loads CSS and JavaScript libraries from CDNs).

## Publish with GitHub Pages

1. Create a **public** repository named `adityarathoreportfolio`.
2. Upload the contents of this folder to the repository root. Keep `index.html` at the root and preserve the `assets/` folder.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, set branch to `main`, and folder to `/(root)`, then save.
5. After deployment, the site should be available at `https://Adityarathore2760.github.io/adityarathoreportfolio/`.

Note: the final URL works only after the repository is created and GitHub Pages deployment completes.
